---
# https://vitepress.dev/reference/default-theme-home-page
layout: home

hero:
  name: "TT高速下载器"
  text: "跨平台、多语言调用的下载器内核"
  tagline: "由 23XR Studio 开发"
  image:
    src: https://images-sxxyrry.pages.dev/TTHSD_Bigger.png
    alt: TT高速下载器
  actions:
    - theme: brand
      text: "快速开始"
      link: "/zh/guide/getting-started"
    - theme: alt
      text: "什么是 TTHSD 核心"
      link: "/zh/guide/what-is-TTHSD-Core"
    - theme: alt
      text: " API 使用"
      link: "/zh/api/API-overview"

features:
  - title: "🌐 7 种下载协议"
    details: "原生支持 HTTP/HTTPS、HTTP/3 (QUIC)、FTP、BitTorrent/Magnet、ED2K、Metalink 4.0"
  - title: "🖥️ 5 大平台覆盖"
    details: "Windows、Linux、macOS、Android、HarmonyOS 全平台动态库编译"
  - title: "🔗 7+ 种语言绑定"
    details: "Rust、Python、Java/Kotlin、C#、Node.js、C/C++、Godot 原生调用"
  - title: "⚡ 极致性能"
    details: "动态分片工作量窃取算法、TLS 指纹伪装、零 GC 停顿、极低内存占用"
---